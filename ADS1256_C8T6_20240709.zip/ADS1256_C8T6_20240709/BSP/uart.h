/*
 * uart.h
 *
 *  Created on: Dec 16, 2022
 *      Author: XWJ
 */

#ifndef BSP_UART_H_
#define BSP_UART_H_


#include <stdio.h>
#include "usart.h"


#endif /* BSP_UART_H_ */
